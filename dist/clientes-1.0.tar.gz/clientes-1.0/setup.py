from setuptools import setup

setup(
    
    name = "clientes",
    version = "1.0",
    description = "Archivo con parametros y metodos para generar instancia de clientes",
    authon = "Pablo Grismado",
    packages = ["modulo_clientes"]
    
)